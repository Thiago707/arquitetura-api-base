package br.edu.unifio.api_delivery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiDeliveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
